# Correction TP4 — Créer une interface responsive

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- Flexbox gère une ligne (en-tête, menu) ; Grid gère une grille (les cartes).
- `rem` suit la taille de police choisie par l’utilisateur ; 1 rem vaut 16 px par défaut.
- `max-width` limite la zone centrale sur grand écran sans provoquer de débordement sur petit écran.
- `max-width: 700px` inclut 700 px : la page passe à une colonne jusqu’à cette largeur incluse.
- `img { max-width: 100%; }` évite le débordement de l’image à 375 px.
- Tester à 375 et 1280 px, puis parcourir la page avec Tab.
