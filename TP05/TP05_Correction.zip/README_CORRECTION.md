# Correction évaluation 1 — HTML et CSS

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- Ne pas distribuer avant l’épreuve.
- La mise en page et la feuille de style diffèrent volontairement du fil rouge Ocean Fest.
- `min-width: 700px` applique exactement la consigne : trois colonnes dès 700 px, une colonne à 699 px.
- Une `max-width: 699px` équivalente est correcte ; `max-width: 700px` donne un écart mineur à 700 px exactement, à ne pas pénaliser lourdement.
