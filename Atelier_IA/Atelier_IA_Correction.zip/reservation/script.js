"use strict";

const places = { recyclage: 2, dessin: 1 };

const formulaire = document.querySelector("#formulaire");
const champNom = document.querySelector("#nom");
const choixAtelier = document.querySelector("#atelier");
const message = document.querySelector("#message");
const reservations = document.querySelector("#reservations");

function ajouterReservation(nom, atelier) {
  places[atelier] = places[atelier] - 1;
  document.querySelector(`#places-${atelier}`).textContent = places[atelier];

  const ligne = document.createElement("li");
  ligne.textContent = `${nom} : ${choixAtelier.selectedOptions[0].textContent}`;
  reservations.append(ligne);
}

formulaire.addEventListener("submit", (evt) => {
  evt.preventDefault();
  const nom = champNom.value.trim();
  const atelier = choixAtelier.value;

  if (nom === "") {
    message.textContent = "Saisissez un nom.";
    champNom.focus();
    return;
  }
  if (places[atelier] === 0) {
    message.textContent = "Cet atelier est complet.";
    return;
  }

  ajouterReservation(nom, atelier);
  message.textContent = "Réservation enregistrée.";
  champNom.value = "";
  champNom.focus();
});
