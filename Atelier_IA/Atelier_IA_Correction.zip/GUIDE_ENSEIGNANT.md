# Guide enseignant : Atelier IA (séance d'essai)

Réservé aux enseignants. Séance non notée, à placer après le TP7.

## Avant la séance
- Vérifier le règlement de l'établissement sur les outils d'IA.
- Tester Duck.ai depuis le réseau de la salle : ses limites d'usage ne sont pas publiées, et de nombreuses demandes depuis une même adresse peuvent être limitées. Prévoir de travailler à deux si besoin.
- Rappeler qu'aucun étudiant n'est obligé d'utiliser une IA : le dossier `secours/` permet de faire toute la séance sans compte ni connexion.

## Les 12 défauts de `audit/`
La page a été générée par une IA, puis des défauts y ont été ajoutés. Elle est volontairement présentable.

| # | Défaut | Où | Correction |
|---|---|---|---|
| 1 | Pas de `lang` | `index.html` | `<html lang="fr">` |
| 2 | Pas de balise viewport | `index.html` | Ajouter la balise |
| 3 | Titre de page vague (`Accueil`) | `index.html` | Titre explicite |
| 4 | Des `div` à la place de `header`, `nav`, `main`, `footer` | `index.html` | Balises sémantiques |
| 5 | Deux `h1`, puis des `h4` et `h5` | `index.html` | Un `h1`, puis `h2`, `h3` |
| 6 | Image sans `alt` | `index.html` | Texte alternatif |
| 7 | `label` non reliés aux champs | `index.html` | `for` et `id` |
| 8 | Faits inventés : 2009, 40 000 festivaliers, dates, gratuité, 1 204 visiteurs, réponse sous 24 heures | `index.html`, `script.js` | Retirer ; s'en tenir à `BRIEF.md` |
| 9 | Formulaire trompeur, avec un service d'envoi inventé | `index.html` | Dire que c'est une démonstration, retirer `action` |
| 10 | Lien cassé vers `programme.html` et largeur fixe de 1100 px (débordement à 375 px) | `index.html`, `styles.css` | Retirer le lien ; `max-width` |
| 11 | Texte des cartes peu contrasté, focus supprimé | `styles.css` | Couleur plus sombre ; retirer `outline: none` |
| 12 | Erreur en console (`#visiteurs` absent), et `innerHTML` avec une saisie | `script.js` | Retirer la ligne ; `textContent` |

Trouver 8 défauts suffit. Les faits inventés (8) et le formulaire trompeur (9) sont les plus instructifs, car aucun outil ne les signale : le code est valide, mais le contenu est faux.

## Réponses de secours
- `secours/reponse_demande_vague.html` invente des dates et un tarif, et demande une carte bancaire. Elle échoue à tous les tests.
- `secours/reponse_demande_precise.html` paraît correcte et réussit T1, T2, T4 et T6. Elle échoue à T3 (pas de `trim`) et à T5 (`innerHTML`), ce qui montre l'intérêt de tester.

Les réponses réelles varient d'une IA et d'un essai à l'autre : corriger avec les tests, pas avec un modèle unique. `reservation/` donne une solution de référence.

## Pendant l'explication à deux
Si quelqu'un ne sait pas expliquer une ligne, l'inviter à la relire avec son binôme, ou à la réécrire plus simplement.

## Évaluer l'essai
- Observer : combien de défauts sont trouvés, et si les tests sont vraiment passés.
- Lire la partie « Bilan » des journaux.
- Décider si l'atelier mérite d'être intégré au cours, par exemple en le découpant entre le TP4 et le TP7.
