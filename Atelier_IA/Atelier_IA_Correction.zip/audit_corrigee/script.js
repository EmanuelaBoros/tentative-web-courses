const formulaire = document.querySelector("#formulaire");

formulaire.addEventListener("submit", (evt) => {
  evt.preventDefault();
  const nom = document.querySelector("#nom").value.trim();
  // textContent affiche la saisie comme du texte, sans l'interpréter comme du HTML.
  document.querySelector("#merci").textContent = `Merci ${nom} !`;
});
