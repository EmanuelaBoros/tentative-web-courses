# Consigne : réservation des ateliers

Créer une page qui permet de réserver une place dans un atelier. Tout reste dans le navigateur : rien n'est envoyé ni enregistré.

## Attendu
- Deux ateliers : Recyclage (2 places) et Dessin (1 place).
- Un formulaire : un nom (fictif), le choix de l'atelier et un bouton.
- Les places restantes de chaque atelier sont affichées.
- La liste des réservations s'affiche sur la page.

## Tests à passer
- **T1.** Au chargement, la page affiche 2 places pour Recyclage et 1 pour Dessin.
- **T2.** Une réservation valide retire une place et ajoute le nom à la liste.
- **T3.** Un nom vide ou composé d'espaces est refusé, avec un message visible.
- **T4.** Un atelier complet refuse la réservation : les places ne deviennent jamais négatives.
- **T5.** Le nom `<b>test</b>` s'affiche tel quel, sans passer en gras.
- **T6.** Tout fonctionne au clavier, et chaque champ a un `label` relié.
