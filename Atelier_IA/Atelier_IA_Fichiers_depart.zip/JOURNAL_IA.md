# Journal de l'atelier IA

Ne jamais y copier de donnée personnelle ni d'identifiant.

Outil utilisé (ou dossier `secours/`) :

## Audit
Défauts trouvés :

Défauts corrigés :

Le défaut le plus difficile à repérer, et pourquoi :

## Génération
Demande vague (copiée telle quelle) :

Ce qui manquait ou était faux dans la réponse :

Demande précise (copiée telle quelle) :

| Test | Réussi du premier coup ? | Ce que vous avez corrigé |
|---|---|---|
| T1 | | |
| T2 | | |
| T3 | | |
| T4 | | |
| T5 | | |
| T6 | | |

Ce que l'IA a inventé ou supposé sans que vous le demandiez :

## Bilan de la séance d'essai
Ce que l'IA vous a fait gagner :

Ce qu'elle vous a fait perdre, ou risquer de ne pas apprendre :

Cette séance devrait-elle rester dans le cours ? Pourquoi ?
