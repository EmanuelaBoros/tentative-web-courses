# Brief d'Ocean Fest

Seuls ces faits sont vrais. Tout autre fait présent sur la page est à vérifier.

- Ocean Fest est un festival culturel fictif, à La Rochelle.
- Il propose des concerts, des ateliers et des rencontres.
- Le site est pédagogique : aucune date, aucun tarif ni aucune fréquentation ne sont connus.
- Le formulaire de contact est une démonstration : il n'envoie rien et doit le dire.
