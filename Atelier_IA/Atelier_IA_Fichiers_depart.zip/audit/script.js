const formulaire = document.querySelector("#formulaire");

formulaire.addEventListener("submit", (evt) => {
  evt.preventDefault();
  const nom = document.querySelector("#nom").value;
  document.querySelector("#merci").innerHTML = "Merci " + nom + " !";
});

// Affiche le nombre de visiteurs du jour
document.querySelector("#visiteurs").textContent = "1 204 visiteurs aujourd’hui";
