# Grille d'audit

Pour chaque ligne : ce que vous avez observé, et le fichier concerné.

| À vérifier | Comment | Observation |
|---|---|---|
| Langue, viewport et titre de la page | Lire le `head` | |
| Balises sémantiques | Chercher `header`, `nav`, `main`, `footer` | |
| Hiérarchie des titres | Un seul `h1`, aucun niveau sauté | |
| Images | Texte alternatif pertinent | |
| Formulaire | Chaque `label` est relié à son champ | |
| Honnêteté du formulaire | Où partent les données ? Que dit la page ? | |
| Liens | Cliquer sur chacun | |
| Faits | Comparer le texte à `BRIEF.md` | |
| Petit écran | Mode responsive à 375 px : défilement horizontal ? | |
| Contraste | Tous les textes sont-ils bien lisibles ? | |
| Clavier | Parcourir avec Tab : le focus est-il visible ? | |
| Console | Ouvrir F12 : y a-t-il une erreur ? | |
| Saisie affichée | Saisir `<b>test</b>` comme nom : que se passe-t-il ? | |
