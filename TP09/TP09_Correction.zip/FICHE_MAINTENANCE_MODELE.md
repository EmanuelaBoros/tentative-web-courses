# Fiche de maintenance modèle
- **Mises à jour :** vérifier régulièrement cœur, thème et extensions, après test sur une copie du site.
- **Sauvegarde :** fichiers et base de données, avec un essai de restauration.
- **Comptes :** droits minimaux, mots de passe robustes, suppression des comptes inutiles.
- **Extensions :** limiter les installations ; vérifier leur source et leur maintenance.
- **Accessibilité :** titres logiques, navigation au clavier, textes alternatifs.
