# Correction TP9 — Personnaliser et administrer WordPress

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

## À retenir
- Cette correction décrit un état attendu : elle ne contient pas d’installation WordPress.
- Commencer par `GUIDE_CORRECTION_WORDPRESS.md`, puis contrôler avec `GRILLE_VALIDATION.csv`.
- `FICHE_MAINTENANCE_MODELE.md` donne un exemple de fiche attendue.
