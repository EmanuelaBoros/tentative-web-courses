# Guide de correction WordPress — TP9

Ce TP part de l’état final du TP8, sur la même instance individuelle.

## État attendu
1. Thème : un thème de blocs actif et une palette cohérente, avec un contraste lisible.
2. Apparence > Éditeur : en-tête avec le nom du site et la navigation ; pied de page personnalisé.
3. Formulaire : extension autorisée, testée avec des données fictives. Sinon, formulaire de démonstration indiqué comme non connecté, et choix documenté dans la fiche.
4. Vérifications : un seul titre de niveau 1 par page, hiérarchie logique, textes alternatifs renseignés, permaliens lisibles, version mobile utilisable.
5. Compte : un compte Éditeur fictif, seulement si autorisé. Justification attendue : ce rôle gère les contenus sans administrer le site (moindre privilège).
6. Fiche de maintenance : voir `FICHE_MAINTENANCE_MODELE.md`.

## SEO de base
Un titre de site explicite, des titres de page clairs, des permaliens lisibles et des textes alternatifs suffisent à ce niveau.

## Points de vigilance
- Aucun mot de passe visible dans les captures.
- Aucune donnée personnelle réelle dans les tests du formulaire.
- Une modification des permaliens doit être suivie d’un nouveau test des liens du menu.
