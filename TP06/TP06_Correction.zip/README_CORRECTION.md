# Correction TP6 — Découvrir JavaScript et les événements

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- `defer` lance le script une fois le HTML analysé : `querySelector` trouve donc les éléments.
- `type="button"` garantit qu’un bouton ne soumet jamais de formulaire.
- Le booléen `nuit` et les deux conditions couvrent les notions du sujet. Une variante avec `classList.toggle` seul et `%` est aussi correcte.
- Erreur volontaire : avec `#themes`, `querySelector` renvoie `null`, et la console affiche `Cannot read properties of null (reading 'addEventListener')`. Lire le numéro de ligne, puis corriger le sélecteur.
- Le thème nuit redéfinit la couleur des liens : le bleu d’origine serait illisible sur fond sombre.
