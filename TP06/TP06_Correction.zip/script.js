"use strict";

const artistes = ["Ariane", "Bastien", "Camille"];
let indice = 0;
let nuit = false;

const boutonTheme = document.querySelector("#theme");
const boutonArtiste = document.querySelector("#artiste");
const sortie = document.querySelector("#sortie");

function basculerTheme() {
  nuit = !nuit;
  document.body.classList.toggle("nuit", nuit);
  if (nuit) {
    boutonTheme.textContent = "Mode jour";
  } else {
    boutonTheme.textContent = "Mode nuit";
  }
}

function afficherArtiste() {
  sortie.textContent = `Prochain artiste : ${artistes[indice]}`;
  indice = indice + 1;
  if (indice === artistes.length) {
    indice = 0;
  }
}

boutonTheme.addEventListener("click", basculerTheme);
boutonArtiste.addEventListener("click", afficherArtiste);

console.log(`Script chargé : ${artistes.length} artistes`);
