Ouvrir index.html dans un navigateur.
Compléter index.html et script.js selon le sujet, sans modifier les valeurs data-type.
