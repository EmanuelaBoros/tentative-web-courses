// Évaluation 2 : écrire ici le code du filtre et du compteur.
