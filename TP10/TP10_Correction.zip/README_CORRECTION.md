# Correction évaluation 2 — JavaScript et WordPress

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- Ne pas distribuer avant l’épreuve.
- Le `select` peut être écrit en HTML ou créé en JavaScript : les deux sont acceptés.
- `hidden` masque l’activité sans la retirer du DOM ; `classList` avec une classe CSS est aussi correct.
- Tester : 6 activités au chargement, 2 pour chaque type, puis 6 avec « Toutes ».
