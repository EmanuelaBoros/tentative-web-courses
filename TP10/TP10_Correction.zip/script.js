"use strict";

const filtre = document.querySelector("#filtre");
const activites = Array.from(document.querySelectorAll("#activites [data-type]"));
const compteur = document.querySelector("#compteur");

function actualiser() {
  const type = filtre.value;
  let nombre = 0;

  activites.forEach((activite) => {
    const visible = type === "tous" || activite.dataset.type === type;
    activite.hidden = !visible;
    if (visible) {
      nombre = nombre + 1;
    }
  });

  const pluriel = nombre > 1 ? "s" : "";
  compteur.textContent = `${nombre} activité${pluriel} affichée${pluriel}`;
}

filtre.addEventListener("change", actualiser);
actualiser();
