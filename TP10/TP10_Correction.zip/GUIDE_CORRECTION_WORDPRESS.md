# Correction de la partie WordPress (enseignant)

Prérequis : instance préparée selon `00_Guide_enseignant_WordPress.pdf`.

1. Pages : créer et publier « Informations pratiques » avec un titre et un texte (accès fictif par exemple).
2. Articles > Catégories : créer « Actualités ».
3. Articles : affecter « Actualités » à l’article « Bilan de la dernière édition ».
4. Ajouter « Informations pratiques » au menu de navigation.
5. Vérifier en mode visiteur et joindre les captures, sans identifiant visible.

Adapter le barème si une limite de l’instance a empêché une action.
