# Correction TP1 — Comprendre le Web et créer une page HTML

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- Le `alt` décrit ce que l’image apporte à la page.
- Un seul `h1`, puis des `h2` : les titres décrivent la structure, pas la taille du texte.
- Les réponses aux questions de cours sont dans `REPONSES_QUESTIONS.md`.
