# Réponses attendues aux questions du TP1

- **Navigateur (client) :** demande les ressources et affiche la page.
- **Serveur :** reçoit la requête HTTP(S) et renvoie les ressources demandées.
- **HTML / CSS / JavaScript :** structure et contenu / présentation / comportement.
- **HTTP et HTTPS :** même protocole d’échange, mais HTTPS chiffre la communication et authentifie le serveur.
- **Exemple d’URL `https://www.larochelle.fr/` :** le protocole est `https`, le nom de domaine `www.larochelle.fr` et le chemin `/`.

En ouvrant `index.html` directement, le navigateur lit un fichier local (`file://`) : aucun serveur n’intervient.
