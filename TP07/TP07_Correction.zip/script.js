"use strict";

const form = document.querySelector("#formulaire");
const champ = document.querySelector("#tache");
const liste = document.querySelector("#liste");
const erreur = document.querySelector("#erreur");
const compteur = document.querySelector("#compteur");

function actualiserCompteur() {
  const n = liste.children.length;
  compteur.textContent = `${n} tâche${n > 1 ? "s" : ""}`;
}

function supprimerTache(li) {
  li.remove();
  actualiserCompteur();
  // Le bouton cliqué a disparu : on replace le focus pour l'usage au clavier.
  champ.focus();
}

function ajouterTache(nom) {
  const li = document.createElement("li");
  const texte = document.createElement("span");
  texte.textContent = `${nom} `;

  const bouton = document.createElement("button");
  bouton.type = "button";
  bouton.textContent = "Supprimer";
  bouton.setAttribute("aria-label", `Supprimer la tâche : ${nom}`);
  bouton.addEventListener("click", () => supprimerTache(li));

  li.append(texte, bouton);
  liste.append(li);
}

form.addEventListener("submit", (evt) => {
  evt.preventDefault();
  const nom = champ.value.trim();

  if (nom === "") {
    erreur.textContent = "Saisissez une tâche.";
    champ.setAttribute("aria-invalid", "true");
    champ.focus();
    return;
  }

  erreur.textContent = "";
  champ.removeAttribute("aria-invalid");
  ajouterTache(nom);
  actualiserCompteur();
  champ.value = "";
  champ.focus();
});
