# Correction TP7 — Manipuler le DOM et valider un formulaire

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- `trim()` refuse une saisie composée uniquement d’espaces.
- `textContent` affiche la saisie comme du texte, sans l’interpréter comme du HTML.
- L’erreur est annoncée par `role="alert"`, reliée au champ par `aria-describedby` et signalée par `aria-invalid`.
- Supprimer un élément qui a le focus renvoie le focus au début de la page : on le replace donc sur le champ.
- `liste.children.length` donne un compteur toujours exact, sans variable à synchroniser.
