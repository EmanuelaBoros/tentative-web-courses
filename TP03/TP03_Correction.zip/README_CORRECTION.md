# Correction TP3 — Mettre en forme un site avec CSS

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- Volontairement sans Flexbox, Grid ni media query : ces notions sont le travail du TP4.
- Carte `.card` : `border` dessine le contour, `padding` éloigne le texte du contour, `margin` éloigne les cartes.
- Sélecteurs concurrents : `.card` et `#carte-phare` visent la première carte. L’id a la spécificité (1,0,0), la classe (0,1,0) : la bordure bleue s’applique, même si l’ordre des règles est inversé. À spécificité égale, la dernière règle gagne.
- Héritage : `color` et `font-family` posés sur `body` se transmettent ; `border` et `padding` ne se transmettent pas.
- Seul ajout HTML autorisé : l’attribut `id="carte-phare"`.
