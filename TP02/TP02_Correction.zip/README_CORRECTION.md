# Correction TP2 — Structurer un site multipage en HTML

Réservée aux enseignants jusqu’à la remise. Cette solution de référence n’est pas la seule possible.

Ouvrir `index.html` dans un navigateur récent ; aucune installation n’est nécessaire.

## À retenir
- Le lien actif combine `aria-current="page"` (lecteurs d’écran) et `strong` (visible sans CSS).
- Le bouton de type `submit` déclenche la vérification des champs `required`.
- `method="get"` place les valeurs dans l’URL : c’est visible après un test, donc utile pour observer. Un vrai formulaire de contact utiliserait POST et un traitement serveur.
- `action="#"` reste sur la page : rien n’est envoyé, et le texte de la page le dit.
- Les classes `cards` et `card` servent de points d’accroche au TP3.
